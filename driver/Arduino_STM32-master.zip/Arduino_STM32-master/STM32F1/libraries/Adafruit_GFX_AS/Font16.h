#define nr_chrs_f16 96
#define chr_hgt_f16 16
#define data_size_f16 8
#define firstchr_f16 32

extern const unsigned char widtbl_f16[96];
extern const unsigned char* const chrtbl_f16[96];
